self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "ca79a6d6f1c6ef56d992f13426eaf60b",
    "url": "/index.html"
  },
  {
    "revision": "aa4b1fcac3c9372f8333",
    "url": "/static/css/2.86df01db.chunk.css"
  },
  {
    "revision": "aa1d6d202460cf90a109",
    "url": "/static/css/main.981f7211.chunk.css"
  },
  {
    "revision": "aa4b1fcac3c9372f8333",
    "url": "/static/js/2.e92f9f8d.chunk.js"
  },
  {
    "revision": "21ced859ea2b2d6b856d461ad6c2afed",
    "url": "/static/js/2.e92f9f8d.chunk.js.LICENSE.txt"
  },
  {
    "revision": "aa1d6d202460cf90a109",
    "url": "/static/js/main.744550da.chunk.js"
  },
  {
    "revision": "da13e4c8c6aec27da14a",
    "url": "/static/js/runtime-main.4e240788.js"
  },
  {
    "revision": "4e1ec8403d903dc514271d7328fbdeb3",
    "url": "/static/media/persik.4e1ec840.png"
  }
]);